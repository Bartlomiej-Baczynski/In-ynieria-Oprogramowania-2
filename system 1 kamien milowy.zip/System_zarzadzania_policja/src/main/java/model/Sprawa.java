package model;

public class Sprawa {
    public String id;
    public String status;
}