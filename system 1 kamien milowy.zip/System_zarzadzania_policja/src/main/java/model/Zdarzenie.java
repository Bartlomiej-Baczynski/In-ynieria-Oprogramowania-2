package model;

public class Zdarzenie {
    public String id;
    public String typ;
    public String lokalizacja;
    public String opis;
    public String status;
    public int priorytet;
    public String idSprawy;
}