import model.Zdarzenie;
import model.Sprawa;
import repository.ZdarzenieRepository;
import repository.SprawaRepository;

public class Main {
    public static void main(String[] args) {
        try {
            SprawaRepository sprawaRepo = new SprawaRepository();

            Sprawa s = new Sprawa();
            s.id = "S3";
            s.status = "OTWARTA";
            sprawaRepo.insert(s);

            ZdarzenieRepository repo = new ZdarzenieRepository();

            Zdarzenie z = new Zdarzenie();
            z.id = "Z10";
            z.idSprawy = "S3";  // powiązanie ze sprawą
            z.typ = "Kradzież";
            z.lokalizacja = "Gdańsk";
            z.opis = "Testowe zdarzenie";
            z.status = "NOWE";
            z.priorytet = 1;

            repo.insert(z);
            repo.selectAll();
            repo.updateStatus("Z10", "ZAMKNIETE");
            repo.selectAll();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
