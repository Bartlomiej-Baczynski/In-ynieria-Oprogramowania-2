package repository;

import database.DBConnection;
import model.Sprawa;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class SprawaRepository {

    public void insert(Sprawa s) throws Exception {
        Connection conn = DBConnection.getConnection();

        PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO SPRAWA (NUMER_SPRAWY, STATUS) VALUES (?, ?)"
        );

        ps.setString(1, s.id);
        ps.setString(2, s.status);

        ps.executeUpdate();
        System.out.println("Dodano sprawę");

        ps.close();
        conn.close();
    }
}
