package repository;

import database.DBConnection;
import model.Zdarzenie;

import java.sql.*;

public class ZdarzenieRepository {

    public void insert(Zdarzenie z) throws Exception {
        Connection conn = DBConnection.getConnection();

        PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO ZDARZENIE (ID_ZDARZENIA, TYP, LOKALIZACJA, CZAS, OPIS, STATUS, PRIORYTET, ID_SPRAWY) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );

        ps.setString(1, z.id);
        ps.setString(2, z.typ);
        ps.setString(3, z.lokalizacja);
        ps.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
        ps.setString(5, z.opis);
        ps.setString(6, z.status);
        ps.setInt(7, z.priorytet);
        ps.setString(8, z.idSprawy);

        ps.executeUpdate();
        System.out.println("Dodano zdarzenie");

        ps.close();
        conn.close();
    }


    public void selectAll() throws Exception {
        Connection conn = DBConnection.getConnection();

        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM ZDARZENIE");

        while (rs.next()) {
            System.out.println(
                    rs.getString("ID_ZDARZENIA") + " | " +
                            rs.getString("TYP") + " | " +
                            rs.getString("STATUS")
            );
        }

        rs.close();
        stmt.close();
        conn.close();
    }

    public void updateStatus(String id, String status) throws Exception {
        Connection conn = DBConnection.getConnection();

        PreparedStatement ps = conn.prepareStatement(
                "UPDATE ZDARZENIE SET STATUS=? WHERE ID_ZDARZENIA=?"
        );

        ps.setString(1, status);
        ps.setString(2, id);

        ps.executeUpdate();

        System.out.println("Zaktualizowano status");

        ps.close();
        conn.close();
    }

    public void delete(String id) throws Exception {
        Connection conn = DBConnection.getConnection();

        PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM ZDARZENIE WHERE ID_ZDARZENIA=?"
        );

        ps.setString(1, id);

        ps.executeUpdate();

        System.out.println("Usunięto zdarzenie");

        ps.close();
        conn.close();
    }
}