import org.junit.jupiter.api.Test;
import repository.ZdarzenieRepository;
import model.Zdarzenie;

public class ZdarzenieRepositoryTest {

    @Test
    void testInsertZdarzenie() throws Exception {
        ZdarzenieRepository repo = new ZdarzenieRepository();

        Zdarzenie z = new Zdarzenie();
        z.id = "ZTEST1";
        z.typ = "Test";
        z.lokalizacja = "Test";
        z.opis = "Test";
        z.status = "NOWE";
        z.priorytet = 1;
        z.idSprawy = "S3"; // musi istnieć w DB

        repo.insert(z);

        System.out.println("TEST OK");
    }
}